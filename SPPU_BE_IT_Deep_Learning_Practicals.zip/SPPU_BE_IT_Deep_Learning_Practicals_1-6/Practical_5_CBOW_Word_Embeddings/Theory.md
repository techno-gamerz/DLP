# Practical 5: Word Embeddings Using the Continuous Bag-of-Words (CBOW) Model

**Aim:** To implement the Continuous Bag-of-Words (CBOW) approach for learning word embeddings from a small text corpus.

## 1. Introduction
Word embeddings represent words as dense numerical vectors. Unlike one-hot encoding, dense embeddings can capture useful similarities and relationships when trained on sufficient text. The Continuous Bag-of-Words (CBOW) model is a Word2Vec architecture that predicts a target word from its surrounding context words.

## 2. CBOW principle
Given a context window around a target word, CBOW combines the context representations—commonly by averaging or summing their embeddings—and predicts the central target word. Training adjusts embedding weights to improve prediction. The context window size controls how many neighboring words contribute to each training example.

## 3. Corpus preprocessing
Text is converted to lowercase and tokenized into words. A vocabulary maps each unique token to an integer ID. For each token position, surrounding tokens within the selected window are used as context, and the current token becomes the target. Positions without enough surrounding context may be skipped.

## 4. Model architecture
The input consists of context word IDs. An embedding layer maps IDs to dense vectors. The context vectors are averaged, and a softmax output layer estimates probabilities over the vocabulary. Cross-entropy loss is minimized with an optimizer such as Adam.

## 5. Learning and interpretation
The learned embedding matrix contains a vector for each vocabulary item. Cosine similarity can compare two word vectors. With a tiny demonstration corpus, the vectors are only illustrative and should not be expected to capture robust linguistic semantics. Larger corpora, suitable hyperparameters and techniques such as negative sampling are commonly used in practical Word2Vec implementations.

## 6. Applications
Word embeddings support text classification, information retrieval, semantic similarity, language processing and downstream neural-network models.

## 7. Conclusion
CBOW learns word representations by predicting a word from its context. This practical demonstrates tokenization, context-target generation, training and similarity inspection on a small corpus.


## Algorithm / Procedure
1. Import the required libraries.
2. Load or prepare the dataset/input as described in the notebook.
3. Preprocess the data and define the model.
4. Train the model or perform inference as appropriate.
5. Evaluate or inspect the output and record the observations.
6. State the conclusion based on the obtained results.

## Result
The practical demonstrates the stated deep-learning concept. Record the actual output and observations obtained when you execute the notebook in your environment.
