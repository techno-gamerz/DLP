# Practical 2: Implementation of a Feedforward Neural Network

**Aim:** To implement a feedforward neural network for classification using the Keras API.

## 1. Introduction
A feedforward neural network (FNN), also called a multilayer perceptron (MLP), is an artificial neural network in which information moves from the input layer through one or more hidden layers to the output layer. There are no feedback connections in the standard architecture.

## 2. Architecture
- **Input layer:** receives a vector of features.
- **Hidden layer(s):** compute weighted sums followed by nonlinear activation functions.
- **Output layer:** produces class scores or probabilities.

For a neuron, the pre-activation value is `z = Wx + b`, and the activation is `a = f(z)`, where `W` is the weight matrix, `b` is the bias vector and `f` is an activation function such as ReLU or sigmoid.

## 3. Training
Training uses forward propagation to calculate predictions, a loss function to measure prediction error, and backpropagation to calculate gradients. An optimizer such as stochastic gradient descent or Adam updates the weights to reduce the loss. Epochs represent passes over the training data; batch size determines how many examples are processed before an update.

## 4. Dataset and preprocessing
The notebook uses the built-in Iris dataset. Each example has four numerical measurements and belongs to one of three classes. Features are standardized so that each feature has approximately zero mean and unit variance. A stratified train/test split preserves class proportions.

## 5. Model design
The model uses a dense hidden layer with ReLU activation and a three-unit output layer with softmax activation. Sparse categorical cross-entropy is appropriate because the target labels are integer class IDs. Accuracy is used as an easy-to-interpret metric.

## 6. Evaluation
The test set estimates performance on unseen examples. A confusion matrix can reveal which classes are confused. Results can vary slightly depending on software versions, initialization and training settings; accuracy on a small dataset should not be interpreted as a guarantee of real-world performance.

## 7. Applications
FNNs are useful for tabular classification and regression, baseline modelling and learning nonlinear relationships between numerical features.

## 8. Conclusion
A feedforward network learns a mapping from input features to target classes by optimizing its weights through backpropagation. Careful preprocessing, held-out evaluation and reproducible settings are essential.


## Algorithm / Procedure
1. Import the required libraries.
2. Load or prepare the dataset/input as described in the notebook.
3. Preprocess the data and define the model.
4. Train the model or perform inference as appropriate.
5. Evaluate or inspect the output and record the observations.
6. State the conclusion based on the obtained results.

## Result
The practical demonstrates the stated deep-learning concept. Record the actual output and observations obtained when you execute the notebook in your environment.
