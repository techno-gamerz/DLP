# SPPU BE IT — Deep Learning Practicals 1–6

This archive contains six practical folders. Each folder includes a Jupyter notebook (`.ipynb`) and an academically written theory file (`Theory.md`).

## Practical list
1. Study of TensorFlow, Keras, Theano and PyTorch
2. Feedforward Neural Network (FNN) for classification
3. CNN image classification using Fashion-MNIST
4. Autoencoder-based anomaly detection
5. Continuous Bag-of-Words (CBOW) word embeddings
6. Object detection using a pretrained CNN-based detector (Faster R-CNN)

## How to run
1. Install Python 3.10–3.12 where possible, then install Jupyter Notebook or JupyterLab.
2. Open a practical's `.ipynb` file and run cells from top to bottom.
3. Install the dependencies listed in the notebook comments. TensorFlow/PyTorch compatibility depends on your operating system, Python version and hardware.
4. Some notebooks download public datasets or pretrained weights on first run and therefore may need internet access.
5. Record the actual output and observations in your practical journal.

## Notes
- The notebooks are intended as clear educational demonstrations, not as production systems.
- Practical 1 checks which frameworks are installed; it does not attempt to install legacy Theano automatically.
- Practical 4 uses synthetic data to demonstrate the anomaly-detection principle.
- Practical 5 uses a very small corpus; its embeddings are illustrative only.
- Practical 6 uses pretrained Faster R-CNN for inference. It does not perform custom dataset fine-tuning; actual fine-tuning requires a labelled bounding-box dataset.
- Results can vary by package version, random initialization and hardware. Execute locally before submitting, and include your own screenshots/observations.
