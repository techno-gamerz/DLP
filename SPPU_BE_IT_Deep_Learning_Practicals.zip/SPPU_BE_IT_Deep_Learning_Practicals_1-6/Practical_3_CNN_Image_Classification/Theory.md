# Practical 3: Image Classification Using a Convolutional Neural Network

**Aim:** To design and train a convolutional neural network (CNN) for image classification.

## 1. Introduction
A convolutional neural network is a deep-learning architecture especially effective for grid-like data such as images. CNNs learn spatial features directly from pixel values and can build increasingly complex representations across layers.

## 2. Main components
- **Convolution layer:** applies learnable filters to detect local patterns such as edges, textures and shapes.
- **Activation function:** ReLU introduces nonlinearity.
- **Pooling layer:** reduces spatial dimensions and can make representations less sensitive to small shifts.
- **Flatten or global pooling:** converts feature maps to a representation suitable for classification.
- **Dense output layer:** maps learned features to class scores.

## 3. Dataset
This practical uses Fashion-MNIST, a dataset of 28 × 28 grayscale images in ten clothing categories. The dataset is provided by Keras and may be downloaded automatically the first time it is loaded; an internet connection may therefore be required on first run.

## 4. Preprocessing
Pixel values originally range from 0 to 255. Dividing by 255 scales them to the range 0 to 1, which generally helps optimization. A channel dimension is added because convolutional layers expect image tensors with height, width and channels.

## 5. Model and training
The network uses convolution and max-pooling layers followed by a dense classifier. The final layer has ten outputs, one for each class. Sparse categorical cross-entropy is used with integer labels, and Adam performs gradient-based optimization.

## 6. Evaluation
Test accuracy and test loss measure performance on held-out images. The test set should not be repeatedly used to tune the model, as doing so can bias the evaluation. More advanced experiments can include data augmentation, dropout and a confusion matrix.

## 7. Applications
CNNs are widely used for object and image classification, medical-image analysis, quality inspection, scene understanding and image retrieval.

## 8. Conclusion
CNNs learn spatial hierarchies of visual features through convolution and pooling. The practical demonstrates the complete workflow from image preprocessing to model evaluation.


## Algorithm / Procedure
1. Import the required libraries.
2. Load or prepare the dataset/input as described in the notebook.
3. Preprocess the data and define the model.
4. Train the model or perform inference as appropriate.
5. Evaluate or inspect the output and record the observations.
6. State the conclusion based on the obtained results.

## Result
The practical demonstrates the stated deep-learning concept. Record the actual output and observations obtained when you execute the notebook in your environment.
