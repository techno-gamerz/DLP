# Practical 1: Study of Deep Learning Frameworks: TensorFlow, Keras, Theano and PyTorch

**Aim:** To study and compare the features, architecture, advantages, limitations and typical applications of TensorFlow, Keras, Theano and PyTorch.

## 1. Introduction
Deep learning is a subfield of machine learning that uses multilayer artificial neural networks to learn hierarchical representations from data. Deep-learning frameworks provide tensor operations, automatic differentiation, neural-network layers, optimizers, model-training utilities and hardware acceleration.

## 2. TensorFlow
TensorFlow is an open-source machine-learning framework originally developed by Google. It provides tensor computation, automatic differentiation, model training, deployment tools and support for CPU, GPU and specialized accelerators. Its high-level Keras API makes it convenient to define and train neural networks. TensorFlow can be used for image classification, natural-language processing, time-series forecasting and production deployment.

## 3. Keras
Keras is a high-level deep-learning API designed to make neural-network development readable and concise. It provides common layers, loss functions, optimizers, callbacks and training workflows. In modern practice, Keras is commonly used through TensorFlow or its supported backends. A Sequential model is suitable for a simple linear stack of layers, while the Functional API supports more complex graphs with multiple inputs or outputs.

## 4. Theano
Theano was a Python library for defining, optimizing and evaluating mathematical expressions, especially multidimensional array operations. It supported symbolic computation and automatic differentiation and was historically important in deep-learning research. The original Theano project is no longer actively developed, so it is mainly of historical and educational interest rather than a recommended choice for new production systems.

## 5. PyTorch
PyTorch is an open-source machine-learning framework widely used in research and application development. It provides tensor operations, automatic differentiation through autograd, neural-network building blocks in `torch.nn`, and optimization utilities. Its eager execution model makes experiments and debugging intuitive. PyTorch supports CPU and GPU computation where compatible hardware and packages are installed.

## 6. Comparison
- **Abstraction:** Keras offers a high-level API; TensorFlow and PyTorch also expose lower-level operations.
- **Execution and debugging:** PyTorch's eager execution is convenient for interactive debugging; TensorFlow supports eager execution and graph-based optimization.
- **Historical significance:** Theano introduced symbolic tensor computation and automatic differentiation workflows that influenced later systems.
- **Deployment:** TensorFlow has a broad deployment ecosystem; PyTorch also offers deployment and serving options that evolve over time.
- **Learning curve:** Keras is often the easiest entry point for standard models; lower-level control requires more framework knowledge.

## 7. Applications
These frameworks are used for computer vision, speech recognition, language modelling, recommendation systems, anomaly detection and scientific computing.

## 8. Conclusion
Each framework provides tools for building neural networks, but they differ in abstraction level, execution model, ecosystem and maintenance status. For new projects, select a currently maintained framework that matches the required workflow and deployment environment; Theano should generally be treated as a legacy framework.


## Algorithm / Procedure
1. Import the required libraries.
2. Load or prepare the dataset/input as described in the notebook.
3. Preprocess the data and define the model.
4. Train the model or perform inference as appropriate.
5. Evaluate or inspect the output and record the observations.
6. State the conclusion based on the obtained results.

## Result
The practical demonstrates the stated deep-learning concept. Record the actual output and observations obtained when you execute the notebook in your environment.
